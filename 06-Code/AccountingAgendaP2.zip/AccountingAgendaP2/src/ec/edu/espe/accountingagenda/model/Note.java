
package ec.edu.espe.accountingagenda.model;

/**
 *
 * @author Edison Ludeña, Bug Busters, DCCO-ESPE
 */
public class Note {
    private String title;
    private String description;
    
    
}
